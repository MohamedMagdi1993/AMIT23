#include <stdio.h>
#include <stdlib.h>
#include "math.h"
#include "myMath.h"
#include "Test1.h"

static int m = 3 ;

int main(void)
{

    printf("m = %d" ,m) ;
    while (1)
    {
    int num,y; char x ;
    int result ;
    scanf("%d%c%d",&num,&x,&y);
    switch (x)
    {
    case '+':
        result = Add2(num,y);
        break;
    case '-':
        result = Sub(num,y);
        break;
    case '*':
        result = Mul(num,y);
        break;
    case '/':
        result = Div(num,y);
        break;
    case '%':
        result = Rem(num,y);
        break;
    default:
        printf("Wrong Operator") ;
    }
printf("%d%c%d=%d\n",num,x,y,result);

    }
    return 0 ;
}
