#ifndef MYMATH_H
#define MYMATH_H
int invaild = 7 ;
int Add (int x , int y );
int Sub (int x , int y );
int Mul (int x , int y );
int Div (int x , int y);
int Rem (int x , int y );
int factorial(int x);

#endif // MYMATH_H

