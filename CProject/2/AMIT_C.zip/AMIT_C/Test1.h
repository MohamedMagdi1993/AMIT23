#include "myMath.h"
int Add2 (int x , int y );



