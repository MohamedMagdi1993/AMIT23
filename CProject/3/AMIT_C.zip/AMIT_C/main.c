#include <stdio.h>
#include <stdlib.h>
#include "math.h"

void swap (char* x , char* y);
int main(void)
{
char x = 5 ;
char y = 7 ;
char * ptr_x = &x ;
char * ptr_y = &y ;
unsigned int Endian = 0x11223344;
unsigned int * EndianPtr = &Endian ;
char * EndianPtr2 =(char *) &Endian ;

printf("%x", *EndianPtr2) ;
//swap (ptr_x,ptr_y) ;
//printf("x = %d , y= %d\n", x,y);
    return 0 ;
}
/*
void swap(char* x , char* y )
{
    char temp = 0 ;
    temp = *x ;
    *x =*y ;
    *y = temp ;
    printf("x = %d , y= %d\n", *x,*y);
}*/
